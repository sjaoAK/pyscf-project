# Contributing to PySCF

See the "How to contribute" section of the PySCF website: https://pyscf.org/contributing.html
