#!/usr/bin/env bash
sudo apt-get -qq install \
    gcc \
    libblas-dev \
    cmake \
    curl
