#!/usr/bin/env bash
#brew reinstall gcc
