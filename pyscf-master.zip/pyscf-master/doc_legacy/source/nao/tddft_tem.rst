.. _nao_tddft_tem:

nao.tddft_tem --- NAO: Electron Energy Loss Spectroscopy Within TDDFT
*********************************************************************

.. automodule:: pyscf.nao.tddft_tem
   :members:
