Scripts and configures, and docker images to build pyscf wheels

## How to build
docker build -t pyscf/pyscf-pypa-env:latest .
docker push pyscf/pyscf-pypa-env:latest
